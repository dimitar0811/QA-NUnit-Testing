﻿using NUnit.Framework;

namespace TestApp.Tests;

[TestFixture]
public class DivisibilityTransformatorTest
{
    [Test]
    public void Test_Transform_EmptyString_ReturnsEmptyString()
    {
        // TODO: finish the test
    }

    [Test]
    public void Test_Transform_InvalidValues_ReturnsEmptyString()
    {
        // TODO: finish the test
    }

    [Test]
    public void Test_Transform_ValidValues_ReturnsTransformedValues()
    {
        // TODO: finish the test
    }

    [Test]
    public void Test_Transform_ZeroOrNotDivisibleValues_ReturnsSameValues()
    {
        // TODO: finish the test
    }
}

