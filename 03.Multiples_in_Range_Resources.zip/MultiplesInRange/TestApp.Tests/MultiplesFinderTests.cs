using System.Linq;
using NUnit.Framework;
using System.Collections.Generic;

namespace TestApp.Tests;

public class MultiplesFinderTests
{
    [Test]
    public void Test_FindMultiples_StartGreaterThanEndNumber_ReturnsErrorMessage()
    {
        
    }

    [Test]
    public void Test_FindMultiples_NoMultiplesOfTheDevisor_ReturnsEmptyString()
    {

    }

    [Test]
    public void Test_FindMultiples_SingleMultipleOfTheDevisor_ReturnsSingleNumber()
    {

    }

    [Test]
    public void Test_FindMultiples_ManyMultiplesOfTheDevisor_ReturnsCorrectNumbersInRange()
    {

    }

    [Test]
    public void Test_FindMultiples_ZeroInRange_ReturnsZero()
    {

    }
}