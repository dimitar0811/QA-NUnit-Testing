﻿using NUnit.Framework;

namespace TestApp.UnitTests;

public class TriangleTests
{
    [Test]
    public void Test_Triangle_OutputMatchesExpected_Size0()
    {
        // TODO: Write your test here...
    }

    [Test]
    public void Test_Triangle_OutputMatchesExpected_Size3()
    {
        // TODO: Write your test here...
    }

    [Test]
    public void Test_Triangle_OutputMatchesExpected_Size5()
    {
        // TODO: Write your test here...
    }
}
