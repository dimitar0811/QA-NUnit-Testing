using System;
using System.Text;
using System.Linq;
using NUnit.Framework;
using System.Collections.Generic;

namespace TestApp.Tests;

public class SentenceQualificatorTests
{
    [Test]
    public void Test_QualifySentence_EmptyString_ReturnsCorrectMessage()
    {
        
    }

    [Test]
    public void Test_QualifySentence_WhitespacesString_ReturnsCorrectMessage()
    {

    }

    [Test]
    public void Test_QualifySentence_EvenAsciiString_ReturnsCorrectMessage()
    {

    }

    [Test]
    public void Test_QualifySentence_OddAsciiString_ReturnsCorrectMessage()
    {

    }
}   

