using System;
using System.Linq;
using System.Text;
using NUnit.Framework;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Diagnostics.Metrics;

namespace TestApp.Tests;

public class LetterTypeCounterTests
{
    [Test]
    public void Test_CountLetterTypes_EmptyString_ReturnEmptyDictionary()
    {

    }

    [Test]
    public void Test_CountLetterTypes_NonLetterString_ReturnNonLetterCountOnly()
    {

    }

    [Test]
    public void Test_CountLetterTypes_NoOddLetterString_ReturnEvenAndNonLetterCount()
    {

    }

    [Test]
    public void Test_CountLetterTypes_NoEvenLetterString_ReturnOddAndNonLetterCount()
    {

    }

    [Test]
    public void Test_CountLetterTypes_AllTypeOfLetterString_ReturnEvenOddAndNonLetterCount()
    {

    }
}
