﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace TestApp.Tests;

[TestFixture]
public class WordLengthAnalyzerTests
{
    [Test]
    public void Test_AnalyzeSentence_EmptyString_ReturnsEmptyDictionary()
    {
        // TODO: finish the test
    }

    [Test]
    public void Test_AnalyzeSentence_InvalidWordsWithDigits_ReturnsEmptyDictionary()
    {
        // TODO: finish the test
    }

    [Test]
    public void Test_AnalyzeSentence_WordsWithDifferentThanLetterSymbols_ReturnsDictionaryOnlyWithValidWordTypesCount()
    {
        // TODO: finish the test
    }

    [Test]
    public void Test_AnalyzeSentence_WholeSentenceWithValidWords_ReturnsAllTypeOfWordsWithCorrectCount()
    {
        // TODO: finish the test
    }
}

